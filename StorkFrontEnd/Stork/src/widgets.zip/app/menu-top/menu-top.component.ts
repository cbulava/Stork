﻿import { Component, OnInit } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'menu-top',
    templateUrl: 'menu-top.component.html'
})
export class MenuTopComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {

    }
    ngOnViewInit() {

    }

}