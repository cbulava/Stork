"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_request_service_1 = require('../shared/http-request.service');
var Widget = (function () {
    function Widget() {
    }
    return Widget;
}());
var WidgetControlService = (function () {
    function WidgetControlService(httpReq) {
        this.httpReq = httpReq;
        this.boxes = [];
        this.showError = false;
        this.curNum = 5;
        this.rgb = "#efefef";
        this.curItemCheck = 0;
        this.itemPositions = [];
        this.basicStockData = ["Bid", "DaysLow", "DaysHigh", "YearsLow", "YearsHigh", "Ask", "AverageDailyVolume", "DaysRange"];
        this.stockSymbols = ["MSFT", "GOOG", "AMZN", "FB"];
        this.currBoxId = 5;
        this.gridConfig = {
            'margins': [9],
            'draggable': true,
            'resizable': true,
            'max_cols': 0,
            'max_rows': 0,
            'visible_cols': 0,
            'visible_rows': 0,
            'min_cols': 1,
            'min_rows': 1,
            'col_width': 1,
            'row_height': 1,
            'cascade': 'up',
            'min_width': 10,
            'min_height': 10,
            'fix_to_grid': false,
            'auto_style': true,
            'auto_resize': false,
            'maintain_ratio': false,
            'prefer_new': false,
            'zoom_on_drag': false,
            'limit_to_screen': false,
        };
        //manually creating boxes and fill them with compoment type 0 (change type to that of your component number to test for now)
        // for (var i = 0; i < 4; i++) {
        // 	this.boxes[i] = { id: i + 1, compId: 0, config: this._generateDefaultItemConfig(), data: [] , name: "box", error: "", type: 0};	
        // 	//this.getStockData(this.stockSymbols[i], i, this.basicStockData);		
        // }
        //modify box component data here
    }
    WidgetControlService.prototype.createTestStocks = function (stockId) {
        for (var i = 0; i < 1; i++) {
            this.boxes.push({ id: i + 1, compId: 0, config: this._generateDefaultItemConfig(), data: [], name: "box", error: "", type: stockId });
        }
    };
    WidgetControlService.prototype.ngOnInit = function () {
    };
    WidgetControlService.prototype.ngOnViewInit = function () {
    };
    WidgetControlService.prototype.refreshWidgetHolder = function () {
    };
    Object.defineProperty(WidgetControlService.prototype, "ratioDisabled", {
        get: function () {
            return (this.gridConfig.max_rows > 0 && this.gridConfig.visible_cols > 0) ||
                (this.gridConfig.max_cols > 0 && this.gridConfig.visible_rows > 0) ||
                (this.gridConfig.visible_cols > 0 && this.gridConfig.visible_rows > 0);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WidgetControlService.prototype, "itemCheck", {
        get: function () {
            return this.curItemCheck;
        },
        set: function (v) {
            console.log(v);
            this.curItemCheck = v;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WidgetControlService.prototype, "curItem", {
        get: function () {
            return this.boxes[this.curItemCheck] ? this.boxes[this.curItemCheck].config : {};
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WidgetControlService.prototype, "getBoxes", {
        get: function () {
            return this.boxes;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(WidgetControlService.prototype, "getGridConfig", {
        get: function () {
            return this.gridConfig;
        },
        enumerable: true,
        configurable: true
    });
    WidgetControlService.prototype.addBox = function () {
        var conf = this._generateDefaultItemConfig();
        conf.payload = this.curNum++;
        this.boxes.push({ id: conf.payload, compId: 1, config: conf, data: [], name: "", error: "", type: 0 });
    };
    WidgetControlService.prototype.removeBox = function () {
        if (this.boxes[this.curItemCheck]) {
            this.boxes.splice(this.curItemCheck, 1);
        }
    };
    WidgetControlService.prototype.updateItem = function (index, event) {
        // Do something here
    };
    WidgetControlService.prototype.onDrag = function (index, event) {
        // Do something here
    };
    WidgetControlService.prototype.onResize = function (index, event) {
        // Do something here
    };
    WidgetControlService.prototype._generateDefaultItemConfig = function () {
        return { 'col': 1, 'row': 1, 'sizex': 70, 'sizey': 10, 'minCols': 30, 'minRows': 10, 'resizable': false, 'draggable': false };
    };
    Object.defineProperty(WidgetControlService.prototype, "currentInitBoxId", {
        get: function () {
            return this.currBoxId;
        },
        enumerable: true,
        configurable: true
    });
    //Stock symbol and widget index to save it to
    WidgetControlService.prototype.getStockData = function (stock, boxIndex, fields) {
        var _this = this;
        var httpData;
        this.httpReq.getStock(stock, fields).subscribe(function (response) {
            if (response.success) {
                _this.boxes[boxIndex].data = response.payload.results;
            }
            else {
            }
        }, function (error) {
            _this.showError = true;
            _this.boxes[boxIndex].error = "Error timeout in Server. Server may be slow, or stock data is updating on Yahoo page.";
        });
    };
    WidgetControlService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_request_service_1.HttpRequestService])
    ], WidgetControlService);
    return WidgetControlService;
}());
exports.WidgetControlService = WidgetControlService;
//# sourceMappingURL=widget-control.service.js.map