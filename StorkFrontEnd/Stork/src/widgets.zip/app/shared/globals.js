"use strict";
'use strict';
exports.sep = '/';
exports.version = "22.2.2";
//place your component in this, the component id of a box aligns with
//the order of the component types in factoryComponents.
//# sourceMappingURL=globals.js.map