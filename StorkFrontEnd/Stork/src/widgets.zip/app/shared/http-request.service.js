"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
var Observable_1 = require('rxjs/Observable');
var http_2 = require('@angular/http');
var HttpRequestService = (function () {
    function HttpRequestService(http) {
        this.http = http;
        this.serverUrl = "http://localhost:9000/";
        this.headers = new http_2.Headers({ 'Content-Type': 'application/json' });
        this.options = new http_2.RequestOptions({ headers: this.headers });
    }
    HttpRequestService.prototype.login = function (email, password) {
        var body = JSON.stringify({ email: email, password: password });
        return this.http.post(this.serverUrl.concat("user/login"), body, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.createAccount = function (email, password, passwordConf) {
        var body = JSON.stringify({ email: email, password: password, passwordConf: passwordConf });
        return this.http.post(this.serverUrl.concat("user"), body, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.getStock = function (stock, fields) {
        var body = JSON.stringify({ fields: fields });
        return this.http.post(this.serverUrl.concat("stock/").concat(stock), body, this.options)
            .map(this.extractData)
            .timeout(6000, new Error("Server Timeout"))
            .catch(this.handleError);
    };
    HttpRequestService.prototype.logout = function (id) {
        var body = JSON.stringify({ id: id });
        return this.http.post(this.serverUrl.concat("user/logout"), body, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.updateUser = function (id, oldEmail, newEmail, oldPassword, newPassword, newPasswordConf) {
        var body = JSON.stringify({ oldEmail: oldEmail, newEmail: newEmail, oldPassword: oldPassword, newPassword: newPassword, newPasswordConf: newPasswordConf });
        return this.http.put(this.serverUrl.concat("user/").concat(id.toString()), body, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.deleteUser = function (id) {
        return this.http.delete(this.serverUrl.concat("user/").concat(id.toString()), this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.getDashboard = function (id) {
        return this.http.get(this.serverUrl.concat("user/").concat(id.toString()).concat("/dashboard"), this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.addWidget = function (id, stockList, widgetType, refresh, x, y, height, width) {
        var body = JSON.stringify({ stockList: stockList, widgetType: widgetType, refresh: refresh, x: x, y: y, height: height, width: width });
        return this.http.post(this.serverUrl.concat("user/").concat(id.toString()).concat("/dashboard"), body, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.getWidget = function (id, widgetid) {
        return this.http.get(this.serverUrl.concat("user/").concat(id.toString()).concat("/dashboard/").concat(widgetid.toString()), this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.deleteWidget = function (id, widgetid) {
        return this.http.delete(this.serverUrl.concat("user/").concat(id.toString()).concat("/dashboard/").concat(widgetid.toString()), this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.updateWidget = function (id, widgetid, stockList, widgetType, refresh, x, y, height, width) {
        var body = JSON.stringify({ stockList: stockList, widgetType: widgetType, refresh: refresh, x: x, y: y, height: height, width: width });
        return this.http.post(this.serverUrl.concat("user/").concat(id.toString()).concat("/dashboard/").concat(widgetid.toString()), body, this.options)
            .map(this.extractData)
            .catch(this.handleError);
    };
    HttpRequestService.prototype.extractData = function (res) {
        var body = res.json();
        return body || {};
    };
    HttpRequestService.prototype.handleError = function (error) {
        // In a real world app, we might use a remote logging infrastructure
        // We'd also dig deeper into the error to get a better message
        var errMsg = (error.message) ? error.message :
            error.status ? error.status + " - " + error.statusText : 'Server error';
        console.error(errMsg); // log to console instead
        return Observable_1.Observable.throw(errMsg);
    };
    HttpRequestService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http])
    ], HttpRequestService);
    return HttpRequestService;
}());
exports.HttpRequestService = HttpRequestService;
//# sourceMappingURL=http-request.service.js.map