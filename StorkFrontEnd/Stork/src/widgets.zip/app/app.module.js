"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var platform_browser_1 = require('@angular/platform-browser');
var forms_1 = require('@angular/forms');
var http_1 = require('@angular/http');
var app_component_1 = require('./app.component');
var home_component_1 = require('./home/home.component');
var login_component_1 = require('./login/login.component');
var account_creation_component_1 = require('./account-creation/account-creation.component');
var menu_top_component_1 = require('./menu-top/menu-top.component');
var widget_holder_component_1 = require('./widget-holder/widget-holder.component');
var widget_sample_component_1 = require('./widget-sample/widget-sample.component');
var widget_listData_component_1 = require('./widget-listData/widget-listData.component');
var widget_showGraph_component_1 = require('./widget-showGraph/widget-showGraph.component');
var edit_component_1 = require('./edit/edit.component');
var app_routing_1 = require('./app.routing');
var data_service_1 = require('./shared/data.service');
var http_request_service_1 = require('./shared/http-request.service');
var widget_control_service_1 = require('./shared/widget-control.service');
var angular2_grid_1 = require("angular2-grid");
var common_1 = require('@angular/common');
var keys_pipe_1 = require('./shared/keys.pipe');
var AppModule = (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        core_1.NgModule({
            imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule, app_routing_1.app_routing, angular2_grid_1.NgGridModule],
            declarations: [app_component_1.AppComponent, home_component_1.HomeComponent, login_component_1.LoginComponent, menu_top_component_1.MenuTopComponent, widget_holder_component_1.WidgetHolderComponent, keys_pipe_1.KeysPipe, edit_component_1.EditComponent, account_creation_component_1.AccountCreationComponent, widget_sample_component_1.WidgetSampleComponent, widget_listData_component_1.WidgetListDataComponent, widget_showGraph_component_1.WidgetShowGraphComponent],
            providers: [data_service_1.DataService, http_request_service_1.HttpRequestService, widget_control_service_1.WidgetControlService, { provide: common_1.LocationStrategy, useClass: common_1.HashLocationStrategy }],
            bootstrap: [app_component_1.AppComponent]
        }), 
        __metadata('design:paramtypes', [])
    ], AppModule);
    return AppModule;
}());
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map