"use strict";
var router_1 = require('@angular/router');
var home_component_1 = require('./home/home.component');
var login_component_1 = require('./login/login.component');
var edit_component_1 = require('./edit/edit.component');
var account_creation_component_1 = require('./account-creation/account-creation.component');
var app_routes = [
    { path: '', pathMatch: 'full', redirectTo: '/login' },
    { path: 'home', component: home_component_1.HomeComponent },
    { path: 'login', component: login_component_1.LoginComponent },
    { path: 'edit', component: edit_component_1.EditComponent },
    { path: 'account-creation', component: account_creation_component_1.AccountCreationComponent }
];
exports.app_routing = router_1.RouterModule.forRoot(app_routes);
//# sourceMappingURL=app.routing.js.map