import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'selector',
    templateUrl: 'path/fileName.component.html'
})
export class ComponentNameComponent implements OnInit {

    constructor() { }

    ngOnInit() { 

    }

}