"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var widget_control_service_1 = require('../shared/widget-control.service');
var widget_sample_component_1 = require('../widget-sample/widget-sample.component');
var widget_listData_component_1 = require('../widget-listData/widget-listData.component');
var widget_showGraph_component_1 = require('../widget-showGraph/widget-showGraph.component');
var BoxId = (function () {
    function BoxId(elementRef) {
        this.elementRef = elementRef;
    }
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], BoxId.prototype, "h", void 0);
    BoxId = __decorate([
        core_1.Directive({
            selector: '[boxid]'
        }), 
        __metadata('design:paramtypes', [core_1.ViewContainerRef])
    ], BoxId);
    return BoxId;
}());
var WidgetHolderComponent = (function () {
    //@ViewChildren("boxList") private boxList: QueryList<ElementRef
    function WidgetHolderComponent(widgetControl, componentfactoryResolver) {
        this.widgetControl = widgetControl;
        this.componentfactoryResolver = componentfactoryResolver;
        this.boxes = [];
        //global for which widget
        this.widgetNum = 2;
        //0 = widget-sample
        //1 = widget-listData
        //2 = widget-showGraph
        this.factoryComponents = [
            widget_sample_component_1.WidgetSampleComponent, widget_listData_component_1.WidgetListDataComponent, widget_showGraph_component_1.WidgetShowGraphComponent
        ];
        //for 0 type in your widget type number from getWidget
        //specify widgetNum
        this.widgetControl.createTestStocks(this.widgetNum);
        //this.widgetControl.createTestStocks(1);
        //this.blist.createComponent(factory);
        this.gridConfig = this.widgetControl.getGridConfig;
        this.boxes = this.widgetControl.getBoxes;
    }
    WidgetHolderComponent.prototype.ngOnInit = function () {
        if (document.location.href.includes("home")) {
            for (var i = 0; i < this.widgetControl.getBoxes.length; i++) {
                this.widgetControl.getBoxes[i].config.resizable = false;
                this.widgetControl.getBoxes[i].config.draggable = false;
            }
        }
        if (document.location.href.includes("edit")) {
            for (var i = 0; i < this.widgetControl.getBoxes.length; i++) {
                this.widgetControl.getBoxes[i].config.resizable = true;
                this.widgetControl.getBoxes[i].config.draggable = true;
            }
        }
    };
    //add your widgets here. return the Type identified by the import at the top
    WidgetHolderComponent.prototype.getWidget = function (i) {
        if (i == 0) {
        }
        if (i == 1) {
        }
        if (i == 2) {
            //insert component
            return widget_showGraph_component_1.WidgetShowGraphComponent;
        }
    };
    WidgetHolderComponent.prototype.ngAfterViewInit = function () {
        //Where all the boxes are filled with their respective components. 
        if (this.widgetNum == 0) {
            var factory = this.componentfactoryResolver.resolveComponentFactory(widget_sample_component_1.WidgetSampleComponent);
        }
        else if (this.widgetNum == 1) {
            var factory = this.componentfactoryResolver.resolveComponentFactory(widget_listData_component_1.WidgetListDataComponent);
        }
        else if (this.widgetNum == 2) {
            var factory = this.componentfactoryResolver.resolveComponentFactory(widget_showGraph_component_1.WidgetShowGraphComponent);
        }
        var temp;
        temp = this.boxids.toArray();
        for (var i = 0; i < this.boxids.length; i++) {
            this.widgetControl.currBoxId = i;
            var factory = this.componentfactoryResolver.resolveComponentFactory(this.getWidget(this.boxes[i].type));
            temp[i].createComponent(factory);
        }
    };
    __decorate([
        core_1.ViewChildren('boxid', { read: core_1.ViewContainerRef }), 
        __metadata('design:type', core_1.QueryList)
    ], WidgetHolderComponent.prototype, "boxids", void 0);
    WidgetHolderComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            selector: 'widget-holder',
            entryComponents: [
                widget_sample_component_1.WidgetSampleComponent, widget_listData_component_1.WidgetListDataComponent, widget_showGraph_component_1.WidgetShowGraphComponent
            ],
            templateUrl: 'widget-holder.component.html',
        }), 
        __metadata('design:paramtypes', [widget_control_service_1.WidgetControlService, core_1.ComponentFactoryResolver])
    ], WidgetHolderComponent);
    return WidgetHolderComponent;
}());
exports.WidgetHolderComponent = WidgetHolderComponent;
//# sourceMappingURL=widget-holder.component.js.map