Here are thge two widgets. The first one is just enter a stock symbol and it shows the data in the table. The second one is the graph. Currently it's just a blank page with a look up button until you enter a stock. The only things I changed outside of the widget-name folders should just be include statements and some stuff to call the widgets. I don't think you'll need to find anything else.

The todos so far are:
-dynamic sizing for the graph
-default stock at widget start/save last symbol looked up